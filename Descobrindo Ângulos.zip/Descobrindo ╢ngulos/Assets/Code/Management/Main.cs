using UnityEngine;

using System;
using System.Collections;

public class Main : MonoBehaviour
{
	Texture2D BackGroundImage;
	
	float Sin , Cos , Tan , Rad;
		
	int Round;
	
	TextBlock SinBlock , CosBlock , TanBlock , RoundBlock , RadBlock;
	
	TextBlock SinBlock2 , CosBlock2 , TanBlock2 , RoundBlock2 , RadBlock2;
	
	TextBox AngleBox;
	
	TextBlock AngleInfo1 , AngleInfo2;
	
	Button InfoButton;
	
	float Angle;
	
	Texture2D SectorImage;
	
	public GameObject Vector;
	
	public static bool DragOn;
	
	// Use this for initialization
	void Start ()
	{		
		BackGroundImage = (Texture2D)Resources.Load("Main");
		
		Angle = 0f;
		
		SinBlock = new TextBlock(new Vector2(100 , 150) , "Seno :");
		SinBlock2 = new TextBlock(new Vector2(200 , SinBlock.BoundingRectangle.y) , string.Empty);
		
		CosBlock = new TextBlock(new Vector2(100 , 200) , "Cosseno :");
		CosBlock2 = new TextBlock(new Vector2(200 , CosBlock.BoundingRectangle.y) , string.Empty);
		
		TanBlock = new TextBlock(new Vector2(100 , 250) , "Tangente :");
		TanBlock2 = new TextBlock(new Vector2(200 , TanBlock.BoundingRectangle.y) , string.Empty);
		
		RoundBlock = new TextBlock(new Vector2(100 , 300) , "Voltas :");
		RoundBlock2 = new TextBlock(new Vector2(200 , RoundBlock.BoundingRectangle.y) , string.Empty);
		
		RadBlock = new TextBlock(new Vector2(100 , 350) , "Radianos :");
		RadBlock2 = new TextBlock(new Vector2(200 , RadBlock.BoundingRectangle.y) , string.Empty);
		
		AngleBox = new TextBox(new Vector2(520 , 450) , Angle.ToString());
		
		AngleInfo1 = new TextBlock(new Vector2(450 , 450) , "Angulo :");
		AngleInfo2 = new TextBlock(new Vector2(600 , 450) , "graus");
			
		InfoButton = new Button("InfoButton" , new Vector2(100 , 500));
		
		NewAngle();
		
		SectorImage = (Texture2D)Resources.Load("AngularSector");
		
		DragOn = false;
	}
	
	// Update is called once per frame
	void Update ()
	{
		if (StateManager.IsOnTransition)
		{
			StateManager.Update();
		}
		else
		{
			if (Input.GetKey(KeyCode.LeftArrow))
			{
				++Angle;
				
				ClampAngle();
			}
			else if (Input.GetKey(KeyCode.RightArrow))
			{
				--Angle;
				
				ClampAngle();
			}
			
			if (DragOn)
			{
				Angle = (int)Vector.transform.rotation.eulerAngles.z;
				
				ClampAngle();
			}
			
			if (Input.GetKeyDown(KeyCode.Escape))
			{
				Application.Quit();
			}
		}
	}
	
	void OnGUI()
	{
		//StateManager.DrawBackGroundImage(BackGroundImage);
		
		SinBlock.Draw();
		SinBlock2.Draw();
		
		CosBlock.Draw();
		CosBlock2.Draw();
		
		TanBlock.Draw();
		TanBlock2.Draw();
		
		RoundBlock.Draw();
		RoundBlock2.Draw();
		
		RadBlock.Draw();
		RadBlock2.Draw();
		
		AngleInfo1.Draw();
		AngleInfo2.Draw();
		
		AngleBox.Draw();
		
		if (GUI.changed)
		{
			NewAngle();
		}
		
		//GUI.DrawTexture(new Rect(400 , 100 , SectorImage.width , SectorImage.height) , SectorImage);
		
		InfoButton.Draw();
			
		if (InfoButton.Clicked)
		{
			if (!StateManager.IsOnTransition)
			{
				StateManager.ChangeState(GameStates.Info);
			}
		}
	}
	
	void NewAngle()
	{		
		if (AngleBox.Text != string.Empty)
		{
			Angle = float.Parse(AngleBox.Text);
		}
		else
		{
			Angle = 0f;
		}
		
		Sin = TwoDC(Mathf.Sin(Angle));
		
		Cos = TwoDC(Mathf.Cos(Angle));
		
		Tan = TwoDC(Mathf.Tan(Angle));
		
		Round = (int)((Angle / 360));
		
		Rad = TwoDC(Angle * Mathf.Deg2Rad);
		
		GetInfoToLayout();
		
		Vector.transform.RotateAround(Vector.collider.bounds.center , Vector.transform.forward , Angle - (int)Vector.transform.rotation.eulerAngles.z);
	}
	
	void GetInfoToLayout()
	{
		SinBlock2.Text = Sin.ToString();
		
		CosBlock2.Text = Cos.ToString();
		
		TanBlock2.Text = Tan.ToString();
		
		RoundBlock2.Text = Round.ToString();
		
		RadBlock2.Text = Rad.ToString();
	}
	
	float TwoDC(float Value)
	{
		return Mathf.Round(Value * 100) / 100;
	}
	
	void ClampAngle()
	{
		Angle = Mathf.Clamp(Angle , 0.0f , float.MaxValue);
		
		AngleBox.Text = Angle.ToString();
		
		NewAngle();
	}
}