using UnityEngine;

using System.Collections;

public class TextBlock
{
	public Rect BoundingRectangle;
	
	public string Text;
	
	static float Width = 100 , Heigth = 50;
	
	public TextBlock (Vector2 Position , string text)
	{		
		Text = text;
		
		BoundingRectangle = new Rect(Position.x , Position.y , Width , Heigth);
	}
	
	public void Draw()
	{
		GUI.Label(BoundingRectangle , Text);
	}
}