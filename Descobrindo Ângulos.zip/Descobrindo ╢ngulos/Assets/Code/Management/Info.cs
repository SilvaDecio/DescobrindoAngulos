using UnityEngine;

using System.Collections;

public class Info : MonoBehaviour
{
	Texture2D BackGroundImage;
	
	// Use this for initialization
	void Start ()
	{
		BackGroundImage = (Texture2D)Resources.Load("Info");
	}
	
	// Update is called once per frame
	void Update ()
	{
		if (StateManager.IsOnTransition)
		{
			StateManager.Update();
		}
		else
		{
			if (Input.GetKeyDown(KeyCode.Escape))
			{
				StateManager.ChangeState(GameStates.Main);
			}
		}
	}
	
	void OnGUI()
	{
		StateManager.DrawBackGroundImage(BackGroundImage);
	}
}