using UnityEngine;

using System.Collections;

public class Intro : MonoBehaviour
{
	Texture2D BackGroundImage;
	
	// Use this for initialization
	void Start ()
	{
		StateManager.Start();
		
		BackGroundImage = (Texture2D)Resources.Load("Intro");
	}
	
	// Update is called once per frame
	void Update ()
	{
		if (StateManager.IsOnTransition)
		{
			StateManager.Update();
		}
		else
		{
			if (Time.time >= 2)
      		{			
				StateManager.ChangeState(GameStates.Main);
      		}
			
			if (Input.GetKeyDown(KeyCode.Escape))
			{
				Application.Quit();
			}
		}
	}
	
	void OnGUI()
	{
		StateManager.DrawBackGroundImage(BackGroundImage);
	}
}