﻿using UnityEngine;

using System.Collections;

public class DragRigidbody : MonoBehaviour
{
	public float Spring , Damper , Drag , AngularDrag , Distance;
	
	public bool AttachToCenterOfMass;
	
	SpringJoint springJoint;
	
	// Use this for initialization
	void Start ()
	{
		Spring = 50.0f;
		Damper = 5.0f;
		Drag = 10.0f;
		AngularDrag = 5.0f;
		Distance = 0.2f;
		
		AttachToCenterOfMass = false;
	}
	
	// Update is called once per frame
	void Update ()
	{		
		// Make sure the user pressed the mouse down
		if (!Input.GetMouseButtonDown(0))
		{
			Main.DragOn = false;
			
			return;
		}
		
		Camera mainCamera = FindCamera();
			
		// We need to actually hit an object
		RaycastHit hit;
		
		if (!Physics.Raycast(mainCamera.ScreenPointToRay(Input.mousePosition) , out hit , 100))
		{
			Main.DragOn = false;
			
			return;
		}
		
		// We need to hit a rigidbody that is not kinematic
		if (!hit.rigidbody || hit.rigidbody.isKinematic)
		{
			Main.DragOn = false;
			
			return;
		}
		
		if (!springJoint)
		{
			GameObject go = new GameObject("Rigidbody dragger");
			
			Rigidbody body = go.AddComponent("Rigidbody") as Rigidbody;
			
			springJoint = go.AddComponent("SpringJoint") as SpringJoint;
			
			body.isKinematic = true;
		}
		
		springJoint.transform.position = hit.point;
		
		if (AttachToCenterOfMass)
		{
			Vector3 anchor = transform.TransformDirection(hit.rigidbody.centerOfMass) + hit.rigidbody.transform.position;
			
			anchor = springJoint.transform.InverseTransformPoint(anchor);
			
			springJoint.anchor = anchor;
		}
		else
		{
			springJoint.anchor = Vector3.zero;
		}
		
		springJoint.spring = Spring;
		
		springJoint.damper = Damper;
		
		springJoint.maxDistance = Distance;
		
		springJoint.connectedBody = hit.rigidbody;
		
		//Main.DragOn = true;
		
		StartCoroutine ("DragObject", hit.distance);
	}
	
	IEnumerator DragObject(float distance)
	{
		float oldDrag = springJoint.connectedBody.drag;
		
		float oldAngularDrag = springJoint.connectedBody.angularDrag;
		
		springJoint.connectedBody.drag = Drag;
		
		springJoint.connectedBody.angularDrag = AngularDrag;
		
		//Camera mainCamera = FindCamera();
		
		while (Input.GetMouseButton(0))
		{
			Ray ray = FindCamera().ScreenPointToRay(Input.mousePosition);
			
			springJoint.transform.position = ray.GetPoint(distance);
			
			yield return new WaitForSeconds(0.0f);
		}
		
		if (springJoint.connectedBody)
		{
			springJoint.connectedBody.drag = oldDrag;
			
			springJoint.connectedBody.angularDrag = oldAngularDrag;
			
			springJoint.connectedBody = null;
		}
		
		Main.DragOn = true;
	}
	
	Camera FindCamera()
	{
		if (camera)
		{
			return camera;
		}
		else
		{
			return Camera.main;
		}
	}
}