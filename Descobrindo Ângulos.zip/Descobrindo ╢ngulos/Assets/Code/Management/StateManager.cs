using UnityEngine;

using System.Collections;
using System.Collections.Generic;

public class StateManager : MonoBehaviour
{	
	public static GameStates CurrentState;
	
	public static bool IsOnTransition;
	
	static bool FadeIn , FadeOut;
	
	static float AlphaChannel , AlphaTax;
	
	static Texture2D TransitionImage;
	
	static string NextScene;
	
	// Use this for initialization
	public static void Start ()
	{		
		CurrentState = GameStates.Intro;
		
		IsOnTransition = false;
		
		NextScene = string.Empty;
		
		FadeIn = false;
		FadeOut = false;
		
		AlphaChannel = 1.0f;
		AlphaTax = 0.02f;
		
		TransitionImage = (Texture2D)Resources.Load("TransitionImage");
	}
	
	// Update is called once per frame
	public static void Update ()
	{
		if (FadeOut)
		{
			AlphaChannel += AlphaTax;
				
			if (AlphaChannel >= 1.0f)
			{
				AlphaChannel = Mathf.Clamp01(AlphaChannel);
				
				FadeOut = false;
				
				FadeIn = true;
				
				Application.LoadLevel(NextScene);
			}
		}
		
		if (FadeIn)
		{
			AlphaChannel -= AlphaTax;
			
			if (AlphaChannel <= 0.0f)
			{
				AlphaChannel = Mathf.Clamp01(AlphaChannel);
				
				FadeIn = false;
			
				IsOnTransition = false;
			}
		}
	}
	
	public static void ChangeState(GameStates NextState)
	{	
		CurrentState = NextState;
		
		NextScene = CurrentState.ToString();
		
		IsOnTransition = true;
		
		FadeOut = true;
	}
	
	public static void DrawBackGroundImage(Texture2D BackGroundImage)
	{
		GUI.DrawTexture( new Rect(0, 0, Screen.width, Screen.height ), BackGroundImage);
		
		if (IsOnTransition)
        {
            GUI.color = new Color(0, 0, 0, AlphaChannel);
			
			GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height ), TransitionImage);
        }
	}
}