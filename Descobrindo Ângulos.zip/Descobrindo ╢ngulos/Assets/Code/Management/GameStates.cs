
public enum GameStates 
{
	None , Intro , Main , Info
}